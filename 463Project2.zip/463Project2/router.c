/*


Pack type:
	INIT_REQUEST:
		router sends id, neightbor routers, link costs
	INIT_RESPONSE:
		Emulator sends router neighbors and link costs
	RT_UPDATE:
		A-> Emulator -> B, contains table


Router Initialization:
	Send INIT_REQUEST to Network Emulator with router-id(0~MAX_ROUTERS-1)
	After receiving all INIT_REQUEST, Emulator sends each router an INIT_RESPONSE

Router Update:
	Every UPDATE_INTERVAL seconds, sends and RT_UPDATE message(table, neighbor)
	to the Emulator

	When A update message to B, each C in A need to indicate the cost / next hop for A -> C 
	Receiving a message from A, B update its table, for each C from A do
	-If C not in B's table, add C to B's table
	-If C in B's table:
		Split Horizon Rule:
			Check if the next hop for A -> C is itself(B) 
			If it is, update for C ignored(A->B->C)
			If not && better, B update B->C (B->A->C)
		Forced update Rule:
			if A is the next hop to C (B->A->C) && A->C becomes higher, B update cost

Router Failures: 
	If no updates have been received from a neightboring router for a 
	FAILURE_DETECTION seconds, A's table mark any next hop of B as inf 
	
	Emulator response INIT_RESPONSE whenever the dead router is restart

	Receiving INIT_RESPONSE, dead router initializes it's table

Convergence: 
	If CONVERGE_TIMEOUT not modified

	Receiving a RT_UPDATE, UpdateRoutes is called to modify the routing table.
	If UPDATE_INTERVAL timer expires, 
		the first ConvertTabletoPkt is called
		A RT_UPDATE is sent to all the neighbors.
	A neighbors are marked as dead if RT_UPDATE is not send for FAILURE_DETECTION times
	UninstallRoutesOnNbrDeath is called to check for routes with the dead nbr
	change Next hop to infinity

	Print log file whenever the table changes, and converged times

	Use fflush to ensure log written

	Routing Table log example:
		SRC -> DEST: NEXT_HOP, COST
		If infinity cost, print out the cost of infinity defined in ne.h,next hop can be anything


	How to run router:
		• router <router id> <ne hostname> <ne UDP port> <router UDP port>
	How to run ne：
		• ne <ne UDP Port> <ConfigFile>


General Steps:
	Init: InitRoutingTbl()
		1. Router Send INIT_REQUEST to ne
		2. ne wait for all routers to send INIT_REQUEST
		3. ne send INIT_RESPONSE to router
	Fail:  UninstallRoutesOnNbrDeath()
		1. no updates received from router to neighbor for FAILURE_DETECTION seconds
			Mark as dead by UninstallRoutesOnNbrDeath()
		2. update table if B is next hop, cost to infinity
		3. when restart, initialize table
	Update: UpdateRoutes() / ConvertTabletoPkt() / PrintRoutes()
		1. Each router update every UPDATE_INTERVAL seconds
			Sends an RT_UPDATE message to ne
			ne send the message to router
		2. If Receive RT_UPDATE packet, UpdateRoutes() is called
		3. If UPDATE_INTERVAL timer expires, ConvertTabletoPkt() is called, RT_UPDATE sent to all neighbors

	Convergence:
		Table has not been modified for CONVERGE_TIMEOUT seconds
		


*/
#include "ne.h"
#include "router.h"
#include <sys/timerfd.h>

int main(int argc, char ** argv) {

	int n;
	int router_send_fd;
	int router_id;
	char * ne_hostname;
	int ne_UDP_port;
	int router_UDP_port;
	FILE * logfile;

	struct sockaddr_in ne_address;
	struct sockaddr_in router_address;


	struct pkt_INIT_REQUEST INIT_REQUEST;
	struct pkt_INIT_RESPONSE INIT_RESPONSE;


	char* routerfile_start;
	char* routerfile_end;
	char* logfileName;
	routerfile_start = "router";
	routerfile_end = ".log";




//Arrange Input argumnet
	if (argc != 5){
		perror("Invalid Number of Inputs");
		return 0;
	}

	router_id = atoi(argv[1]);
	ne_hostname = argv[2];
	ne_UDP_port = atoi(argv[3]);
	router_UDP_port = atoi(argv[4]);

//Create the file pointer
	logfileName = (char *) malloc(1+strlen(routerfile_start)+strlen(argv[1])+strlen(routerfile_end));
	strcpy(logfileName, routerfile_start);
	strcat(logfileName, argv[1]);
	strcat(logfileName, routerfile_end);



//Check if sock created
	if((router_send_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
	 	perror("\nSocket failed to create\n");
		return 0;
	}

//Set up Router address
  	bzero((char *) &router_address, sizeof(router_address)); 
	router_address.sin_family = AF_INET;
	router_address.sin_addr.s_addr = htonl(INADDR_ANY);
	router_address.sin_port = htons((unsigned short)router_UDP_port);

//Set up ne address
  	bzero((char *) &ne_address, sizeof(ne_address)); 
	ne_address.sin_family = AF_INET;
	ne_address.sin_port = htons((unsigned short)ne_UDP_port);
	inet_aton(ne_hostname, &ne_address.sin_addr);
	INIT_REQUEST.router_id = htonl(router_id);


//Send initial request to ne
	sendto(router_send_fd, (struct pkt_INIT_REQUEST *)&INIT_REQUEST, sizeof(INIT_REQUEST), 0, (struct sockaddr *)&ne_address, sizeof(ne_address));

//Receive initial request from ne
	n = recvfrom(router_send_fd, (struct pkt_INIT_RESPONSE *)&INIT_RESPONSE, sizeof(INIT_RESPONSE), 0, NULL, NULL);


//Convert struct pkt_INIT_RESPONSE (INIT_RESPONSE) from network to host byte order
	ntoh_pkt_INIT_RESPONSE(&INIT_RESPONSE);

//Initializes the routing table with the bootstrap neighbor information in INIT_RESPONSE
	InitRoutingTbl(&INIT_RESPONSE, router_id);

//Create logfile for this router
	logfile = fopen(logfileName, "w");

	if(logfile == NULL){
     	perror("Error opening router file");		
	}

//Print the first router info in log file
	PrintRoutes(logfile, router_id);	

//Construct UDP connection
	struct pkt_RT_UPDATE packetToSend;
	struct pkt_RT_UPDATE packetReceived;

//For Select Function
  	fd_set rfds;

//4 Timer Selection: 
  	//it_value : how long the time will go off
  	//it_interval: the time to reload timer, if 0 -> one-short timer
  	//tv_sec: time in sec
  	//tv_nsec: time in nsec
  	//timerfd_create() creates a new timer object, and returns a file descriptor that refers to that timer.
  	//timerfd_settime() start or stop a timer

  	//Start Update Timer
  	int time_to_update_fd;
  	struct itimerspec timer_for_update;
  	timer_for_update.it_value.tv_sec = UPDATE_INTERVAL;
  	timer_for_update.it_value.tv_nsec = 0;
  	timer_for_update.it_interval.tv_sec = 0;
  	timer_for_update.it_interval.tv_nsec = 0;
  	time_to_update_fd = timerfd_create(CLOCK_REALTIME, 0);
  	timerfd_settime(time_to_update_fd, 0, &timer_for_update, NULL);

  	//Start Converge Timer
  	int time_to_converge_fd;
  	struct itimerspec timer_for_converge;
  	timer_for_converge.it_value.tv_sec = CONVERGE_TIMEOUT;
   	timer_for_converge.it_value.tv_nsec = 0;
  	timer_for_converge.it_interval.tv_sec = 0;
   	timer_for_converge.it_interval.tv_nsec = 0;
  	time_to_converge_fd = timerfd_create(CLOCK_REALTIME, 0);
  	timerfd_settime(time_to_converge_fd, 0, &timer_for_converge, NULL);
  	
  	//Real Timer
  	int time_to_beReal_fd;
  	struct itimerspec timer_for_real;
  	timer_for_real.it_value.tv_sec = 0;
  	timer_for_real.it_value.tv_nsec = 250000000;
  	timer_for_real.it_interval.tv_sec = 0;
  	timer_for_real.it_interval.tv_nsec = 0;
  	time_to_beReal_fd = timerfd_create(CLOCK_REALTIME, 0);
  	timerfd_settime(time_to_beReal_fd, 0, &timer_for_real, NULL);

  	//Neighbor Failure timer
  	int time_to_fail_fd[INIT_RESPONSE.no_nbr];
  	struct itimerspec timer_for_fail[INIT_RESPONSE.no_nbr];
  	int i;
  	int nfds;
  	int nbr_dead_recorder[INIT_RESPONSE.no_nbr];
    int sender_idx;
    int converge_recorder;
    int current_time_sec;
	int current_time_qtr_sec;
	int retval;

  	for (i = 0; i < INIT_RESPONSE.no_nbr; i++){
  		timer_for_fail[i].it_value.tv_sec = FAILURE_DETECTION;
  		timer_for_fail[i].it_value.tv_nsec = 0;
  		timer_for_fail[i].it_interval.tv_sec = 0;
  		timer_for_fail[i].it_interval.tv_nsec = 0;
  		time_to_fail_fd[i] = timerfd_create(CLOCK_REALTIME,0);
   		timerfd_settime(time_to_fail_fd[i], 0, &timer_for_fail[i], NULL);
   		nbr_dead_recorder[i] = 0;
  	}

  	//Select MAX fd as the input of Select function
  	nfds = time_to_update_fd;
  	if (nfds < time_to_converge_fd){
  		nfds = time_to_converge_fd;
  	}
  	if (nfds < time_to_beReal_fd){
  		nfds = time_to_beReal_fd;
  	}
  	for (i = 0; i < INIT_RESPONSE.no_nbr; i++){
  		if (nfds < time_to_fail_fd[i]){
  			nfds = time_to_fail_fd[i];
  		}
  	}

  	nfds = nfds + 1;


/*
General Steps:
	Init: InitRoutingTbl()
		1. Router Send INIT_REQUEST to ne - done
		2. ne wait for all routers to send INIT_REQUEST -done
		3. ne send INIT_RESPONSE to router -done
	Fail:  UninstallRoutesOnNbrDeath()
		1. no updates received from router to neighbor for FAILURE_DETECTION seconds
			Mark as dead by UninstallRoutesOnNbrDeath()
		2. update table if B is next hop, cost to infinity
		3. when restart, initialize table
	Update: UpdateRoutes() / ConvertTabletoPkt() / PrintRoutes()
		1. Each router update every UPDATE_INTERVAL seconds
			Sends an RT_UPDATE message to ne
			ne send the message to router
		2. If Receive RT_UPDATE packet, UpdateRoutes() is called
		3. If UPDATE_INTERVAL timer expires, ConvertTabletoPkt() is called, RT_UPDATE sent to all neighbors

	Convergence:
		Table has not been modified for CONVERGE_TIMEOUT seconds

*/
	  while (1) {
	    FD_ZERO(&rfds);
	    FD_SET(router_send_fd, &rfds);	    
	    FD_SET(time_to_update_fd, &rfds);
	    FD_SET(time_to_converge_fd, &rfds);
	    FD_SET(time_to_beReal_fd, &rfds);
	    for (i = 0; i < INIT_RESPONSE.no_nbr; i++) {
	    	FD_SET(time_to_fail_fd[i], &rfds);
	    }

	    retval = select(nfds, &rfds, NULL, NULL, NULL);  


	    if (FD_ISSET(router_send_fd, &rfds)){
	    	//Receive packet from ne with information regard to neighbors
	    	n = recvfrom(router_send_fd, (struct pkt_RT_UPDATE *)&packetReceived, sizeof(packetReceived), 0, NULL, NULL);

	    	//Convert to byte 
	    	ntoh_pkt_RT_UPDATE(&packetReceived);

	    	//Find the index of the which neighbor router send the packet to the this router
	    	for (i = 0; i < INIT_RESPONSE.no_nbr; i++){
	    		if (packetReceived.sender_id == INIT_RESPONSE.nbrcost[i].nbr) {
	    			sender_idx = i;
	    		}
	    	}

			printf("Receive RT_UPDATE from R%d with cost %d containing %d routes\n", packetReceived.sender_id, INIT_RESPONSE.nbrcost[sender_idx].cost, packetReceived.no_routes);

			//Update routing table with distance vector protocol
	    	n = UpdateRoutes(&packetReceived, INIT_RESPONSE.nbrcost[sender_idx].cost, router_id);

	    	//If update
	    	if (n) {
	    		//print routing table in logfile
	    		PrintRoutes(logfile, router_id);
	    		//Reset Converge timer
			  	timer_for_converge.it_value.tv_sec = CONVERGE_TIMEOUT;
			  	timer_for_converge.it_value.tv_nsec = 0;
			  	timerfd_settime(time_to_converge_fd, 0, &timer_for_converge, NULL);	    		
	    		converge_recorder = 0;
	    	}

	    	//Reset Failure timer
	    	timer_for_fail[sender_idx].it_value.tv_sec = FAILURE_DETECTION;
	    	timer_for_fail[sender_idx].it_value.tv_nsec = 0;
   			timerfd_settime(time_to_fail_fd[sender_idx], 0, &timer_for_fail[sender_idx], NULL);
   			nbr_dead_recorder[sender_idx] = 0;

   			fflush(logfile);
	    }

	    if(FD_ISSET(time_to_update_fd, &rfds)){
	    	//Convert to UDP packet
			bzero((char *)&packetToSend, sizeof(packetToSend));
			ConvertTabletoPkt(&packetToSend, router_id);

			//Send the update packet with the whole routing table neighbors
			for (i = 0; i < INIT_RESPONSE.no_nbr; i++) {
				
				packetToSend.dest_id = INIT_RESPONSE.nbrcost[i].nbr;
				hton_pkt_RT_UPDATE(&packetToSend);

				sendto(router_send_fd, (struct pkt_RT_UPDATE *)&packetToSend, sizeof(packetToSend), 0, (struct sockaddr *)&ne_address, sizeof(ne_address));
				//Convert from network byte to host
    			ntoh_pkt_RT_UPDATE(&packetToSend);
			}

			//Reset update  timer 
			timer_for_update.it_value.tv_sec = UPDATE_INTERVAL;
			timer_for_update.it_value.tv_nsec = 0;
			timerfd_settime(time_to_update_fd, 0, &timer_for_update, NULL);


			if (converge_recorder) {
				printf("%d:Routing Table Converged\n", current_time_sec);
			}

			for (i = 0; i < INIT_RESPONSE.no_nbr; i++) {
				if(nbr_dead_recorder[i]) {
					printf("Neighbor R%d is dead or link to it is down\n", INIT_RESPONSE.nbrcost[i].nbr);
				}
			}
			fflush(logfile);
	    }
	    if(FD_ISSET(time_to_converge_fd, &rfds)){
	    	//Print out total time take to converge
			if (converge_recorder != 1) {
				fprintf(logfile, "%d:Converged\n", current_time_sec);
			}
			
			timer_for_converge.it_value.tv_sec = CONVERGE_TIMEOUT;
			timer_for_converge.it_value.tv_nsec = 0;
			timerfd_settime(time_to_converge_fd, 0, &timer_for_converge, NULL);
			
			converge_recorder = 1;
			fflush(logfile);
	    }
	    if(FD_ISSET(time_to_beReal_fd, &rfds)){
			current_time_qtr_sec = (current_time_qtr_sec + 1) % 4;
			if (current_time_qtr_sec == 3) {
				current_time_sec += 1;
			}
			timer_for_real.it_value.tv_sec = 0;
			timer_for_real.it_value.tv_nsec = 250000000;
			timerfd_settime(time_to_beReal_fd, 0, &timer_for_real, NULL);
	    }

		// Neighbor timeout
		for (i = 0; i < INIT_RESPONSE.no_nbr; i++) {
			//Check if the neighbor dead
			if(FD_ISSET(time_to_fail_fd[i], &rfds)) {

				//Once the neighbor is found to be dead
				if (nbr_dead_recorder[i] == 0) {
					UninstallRoutesOnNbrDeath(INIT_RESPONSE.nbrcost[i].nbr);
					PrintRoutes(logfile, router_id);

					// Reset converged timer
					timer_for_converge.it_value.tv_sec = CONVERGE_TIMEOUT;
					timer_for_converge.it_value.tv_nsec = 0;
					timerfd_settime(time_to_converge_fd, 0, &timer_for_converge, NULL);
					converge_recorder = 0;
					
					fflush(logfile);
				}
				//Assgign neighbor to be dead
				nbr_dead_recorder[i] = 1;
			}
		}	

	  }
	     fclose(logfile);
		return 0;
	}